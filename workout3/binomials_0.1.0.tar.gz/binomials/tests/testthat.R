library(testthat)
library(binomials)

test_check("binomial")
