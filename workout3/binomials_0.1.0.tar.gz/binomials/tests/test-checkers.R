context("Context for Checkers")

test_that("check_prob has a valid probability", {

  expect_true(check_prob(prob = 1))
  expect_true(check_prob(prob < 1))
  expect_true(check_prob(prob > 0))
  expect_true(check_prob(prob = 0))
})

test_that("check_prob has an invalid probability", {

  expect_error(check_prob(prob > 1))
  expect_error(check_prob(prob < 0))

})


test_that("check_trials has a valid number of trials", {

  expect_true(check_trials(trials > 0))
  expect_true(check_trials(floor(trials)))
})

test_that("check_trials has an invalid number of trials", {

  expect_error(check_trials(trials < 0))

})


test_that("check_success has a valid number of successes and trials", {

  expect_true(check_success(success,trial))
})

test_that("check_success has an invalid number of successes and trials", {

  expect_error(check_success(success > trials))
  expect_error(check_success(success > 0))

})

