# Workout3 README 

- Author: Kimberly Chua
- Date: April 30, 2019
- GSI: Dodo Qian
- Section: 102

#### **Files & Descriptions:**

*Files of workout3:*

- 


*Description of workout3:*

- workout3's purpose is to purpose of this assignment is to create an R package that implements functions for calculating probabilities of a Binomial random variable, and related calculations such as the probability distribution, the expected value, variance, etc.
