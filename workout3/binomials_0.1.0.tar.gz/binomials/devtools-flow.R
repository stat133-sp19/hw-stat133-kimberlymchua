library(devtools)

devtools::my_vignettes(introduction.Rmd)
devtools::build_vignettes
